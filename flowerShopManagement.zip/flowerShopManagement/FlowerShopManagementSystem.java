package flowerShopManagement;

import java.util.ArrayList;
import java.util.Scanner;

// Abstract class Flower
abstract class Flower {
    protected String name;
    protected double price;
    protected int quantity;

    // Constructor
    public Flower(String name, double price, int quantity) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    // Abstract method to display flower details
    public abstract void display();
}

// Subclass representing flowers with color
class FlowerWithColor extends Flower {
    private String color;

    public FlowerWithColor(String name, double price, int quantity, String color) {
        super(name, price, quantity);
        this.color = color;
    }

    @Override
    public void display() {
        System.out.println("Flower: " + name + " (Color: " + color + "), Price: $" + price + ", Quantity: " + quantity);
    }

    public String getColor() {
        return color;
    }
}

// Subclass representing flowers without color
class FlowerWithoutColor extends Flower {
    public FlowerWithoutColor(String name, double price, int quantity) {
        super(name, price, quantity);
    }

    @Override
    public void display() {
        System.out.println("Flower: " + name + " (No Color), Price: $" + price + ", Quantity: " + quantity);
    }
}

// Interface for managing orders
interface OrderManagement {
    void addFlower(Flower flower);
    void removeFlower(String name, double price, int quantity, boolean withColor, String color);
    void displayInventory();
}

// Flower Shop class implementing the OrderManagement interface
class FlowerShop implements OrderManagement {
    private ArrayList<Flower> flowers;

    public FlowerShop() {
        flowers = new ArrayList<>();
    }

    @Override
    public void addFlower(Flower flower) {
        for (Flower f : flowers) {
            if (f.name.equalsIgnoreCase(flower.name) && f.price == flower.price) {
                f.quantity += flower.quantity;
                System.out.println(flower.name + " quantity updated to " + f.quantity + ".");
                return;
            }
        }
        flowers.add(flower);
        System.out.println(flower.name + " has been added.");
    }

    @Override
    public void removeFlower(String name, double price, int quantity, boolean withColor, String color) {
        for (Flower f : flowers) {
            if (f.name.equalsIgnoreCase(name) && f.price == price) {
                if (withColor && f instanceof FlowerWithColor) {
                    FlowerWithColor coloredFlower = (FlowerWithColor) f;
                    if (coloredFlower.getColor().equalsIgnoreCase(color)) {
                        checkAndAdjustQuantity(coloredFlower, quantity, name);
                        return;
                    }
                } else if (!withColor && f instanceof FlowerWithoutColor) {
                    checkAndAdjustQuantity(f, quantity, name);
                    return;
                }
            }
        }
        System.out.println("Flower not found with specified name, price, and color.");
    }

    private void checkAndAdjustQuantity(Flower flower, int quantityToRemove, String name) {
        if (quantityToRemove > flower.quantity) {
            System.out.println("Error: Cannot remove " + quantityToRemove + " " + name + "(s). Only " + flower.quantity + " available.");
        } else {
            if (quantityToRemove >= flower.quantity) {
                flowers.remove(flower);
                System.out.println(name + " has been fully removed.");
            } else {
                flower.quantity -= quantityToRemove;
                System.out.println(quantityToRemove + " " + name + "(s) removed. Remaining quantity: " + flower.quantity);
            }
        }
    }

    @Override
    public void displayInventory() {
        if (flowers.isEmpty()) {
            System.out.println("The inventory is empty.");
        } else {
            System.out.println("Flower Shop Inventory:");
            for (Flower flower : flowers) {
                flower.display();
            }
        }
    }
}

// Main class for managing the shop
public class FlowerShopManagementSystem {
    public static void main(String[] args) {
        FlowerShop shop = new FlowerShop();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n1. Add Flower\n2. Remove Flower\n3. Display Inventory\n4. Exit");
            System.out.print("Choose an option: ");
            int choice;

            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
                continue;
            }

            switch (choice) {
                case 1:
                    System.out.print("Enter Flower Type (1 for Flower with Color, 2 for Flower without Color): ");
                    int type = scanner.nextInt();
                    scanner.nextLine();

                    System.out.print("Enter Flower Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Price: ");
                    double price = scanner.nextDouble();
                    System.out.print("Enter Quantity: ");
                    int quantity = scanner.nextInt();
                    scanner.nextLine();

                    if (type == 1) {
                        System.out.print("Enter Color: ");
                        String color = scanner.nextLine();
                        shop.addFlower(new FlowerWithColor(name, price, quantity, color));
                    } else {
                        shop.addFlower(new FlowerWithoutColor(name, price, quantity));
                    }
                    break;

                case 2:
                    System.out.print("Enter Flower Name to Remove: ");
                    String flowerName = scanner.nextLine();
                    System.out.print("Enter Price of Flower to Remove: ");
                    double flowerPrice = scanner.nextDouble();
                    System.out.print("Enter Quantity to Remove: ");
                    int removeQuantity = scanner.nextInt();
                    scanner.nextLine();

                    System.out.print("Is the flower with color? (yes/no): ");
                    String colorResponse = scanner.nextLine();
                    boolean withColor = colorResponse.equalsIgnoreCase("yes");
                    String color = "";

                    if (withColor) {
                        System.out.print("Enter Color: ");
                        color = scanner.nextLine();
                    }

                    shop.removeFlower(flowerName, flowerPrice, removeQuantity, withColor, color);
                    break;

                case 3:
                    shop.displayInventory();
                    break;

                case 4:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid option, please try again.");
            }
        }
    }
}
